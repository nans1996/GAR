package com.gar.payingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayingServiceApplication.class, args);
	}
}
